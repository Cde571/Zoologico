package controller;

public class Invoice {
    private static int countSales;
    public static void increaseCountSales(){
        countSales++;
    }
}

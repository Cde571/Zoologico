package controller;

public interface ConvertToIncome {
    float calculatePrice();
}
